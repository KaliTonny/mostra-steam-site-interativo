
// PERFIL
let btnEditar = document.getElementById("btnEditar");
if (btnEditar) {
  btnEditar.addEventListener("click", function () {
    let novoNome = prompt("Digite seu nome:");
    let novoEmail = prompt("Digite seu email:");

    if (novoNome) {
      document.getElementById("nome").textContent = "Nome: " + novoNome;
      localStorage.setItem("nome", novoNome);
    }

    if (novoEmail) {
      document.getElementById("email").textContent = "Email: " + novoEmail;
      localStorage.setItem("email", novoEmail);
    }
  });
}

// Carregar dados salvos
let nomeSalvo = localStorage.getItem("nome");
let emailSalvo = localStorage.getItem("email");

if (nomeSalvo && document.getElementById("nome")) {
  document.getElementById("nome").textContent = "Nome: " + nomeSalvo;
}

if (emailSalvo && document.getElementById("email")) {
  document.getElementById("email").textContent = "Email: " + emailSalvo;
}


// BOTÃO SAIR
let btnSair = document.getElementById("btnSair");

if (btnSair) {
  btnSair.addEventListener("click", function () {
    alert("Você saiu da conta!");
    window.location.href = "home.html";
  });
}


// FORM CONTATO
let form = document.getElementById("formContato");

if (form) {
  let nome = document.getElementById("nome");
  let email = document.getElementById("email");
  let mensagem = document.getElementById("mensagem");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    if (nome.value === "" || email.value === "" || mensagem.value === "") {
      alert("Preencha todos os campos!");
    } else {
      alert("Mensagem enviada com sucesso!");
      form.reset();
    }
  });
}

// CONFIGURAÇÕES

// MODO ESCURO
let modoEscuro = document.getElementById("modoEscuro");

if (modoEscuro) {
  modoEscuro.addEventListener("change", function () {
    document.body.classList.toggle("dark");
    localStorage.setItem("dark", modoEscuro.checked);
  });

  if (localStorage.getItem("dark") === "true") {
    document.body.classList.add("dark");
    modoEscuro.checked = true;
  }
}

// AUMENTAR FONTE
let fonte = document.getElementById("aumentarFonte");

if (fonte) {
  fonte.addEventListener("change", function () {
    document.body.classList.toggle("big-text");
    localStorage.setItem("fonte", fonte.checked);
  });

  if (localStorage.getItem("fonte") === "true") {
    document.body.classList.add("big-text");
    fonte.checked = true;
  }
}

// RESETAR
let btnReset = document.getElementById("btnReset");

if (btnReset) {
  btnReset.addEventListener("click", function () {
    localStorage.clear();
    location.reload();
  });
}


// PROJETOS

let btn1 = document.getElementById("btnProjeto1");
let btn2 = document.getElementById("btnProjeto2");
let btn3 = document.getElementById("btnProjeto3");

if (btn1) {
  btn1.addEventListener("click", function () {
    let detalhe = document.getElementById("detalhe1");

    if (detalhe.style.display === "none") {
      detalhe.style.display = "block";
    } else {
      detalhe.style.display = "none";
    }
  });
}

if (btn2) {
  btn2.addEventListener("click", function () {
    let detalhe = document.getElementById("detalhe2");

    if (detalhe.style.display === "none") {
      detalhe.style.display = "block";
    } else {
      detalhe.style.display = "none";
    }
  });
}

if (btn3) {
  btn3.addEventListener("click", function () {
    alert("Aqui você verá todos os eventos da cidade!");
  });
}


let links = document.querySelectorAll("nav a");

links.forEach(function(link) {
  link.addEventListener("click", function() {

    links.forEach(l => l.classList.remove("active"));

    this.classList.add("active");

  });
});

const slides = [
  {
    imagem: "img/museu.jpg",
    titulo: "História e natureza em um só lugar",
    texto: "Conheça pontos marcantes de Candeias com uma experiência moderna e interativa."
  },
  {
    imagem: "img/igreja.jpg",
    titulo: "Fé, cultura e tradição",
    texto: "Explore igrejas, monumentos e lugares que fazem parte da identidade da cidade."
  },
  {
    imagem: "img/fonte.jpg",
    titulo: "Lazer para descobrir e viver",
    texto: "Encontre espaços para visitar, registrar momentos e aproveitar Candeias de outro jeito."
  }
];

let index = 0;
let tempoBanner;

const bannerImg = document.getElementById("banner-img");
const bannerTitle = document.getElementById("banner-title");
const bannerText = document.getElementById("banner-text");
const prev = document.getElementById("prev");
const next = document.getElementById("next");

function mostrarSlide() {
  bannerImg.style.opacity = 0;

  setTimeout(() => {
    bannerImg.src = slides[index].imagem;
    bannerTitle.textContent = slides[index].titulo;
    bannerText.textContent = slides[index].texto;
    bannerImg.style.opacity = 1;
  }, 180);
}

function proximoSlide() {
  index = (index + 1) % slides.length;
  mostrarSlide();
}

function slideAnterior() {
  index = (index - 1 + slides.length) % slides.length;
  mostrarSlide();
}

function reiniciarTempo() {
  clearInterval(tempoBanner);
  tempoBanner = setInterval(proximoSlide, 5000);
}

next.addEventListener("click", () => {
  proximoSlide();
  reiniciarTempo();
});

prev.addEventListener("click", () => {
  slideAnterior();
  reiniciarTempo();
});

mostrarSlide(); // 👈 ESSENCIAL
tempoBanner = setInterval(proximoSlide, 5000);